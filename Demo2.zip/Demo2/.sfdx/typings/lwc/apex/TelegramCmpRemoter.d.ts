declare module "@salesforce/apex/TelegramCmpRemoter.sendMessage" {
  export default function sendMessage(param: {contactId: any, messageBody: any}): Promise<any>;
}
