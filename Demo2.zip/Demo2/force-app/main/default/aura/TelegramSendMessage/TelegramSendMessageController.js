({
    sendClick : function(component, event, helper) {
        helper.sendMessage(component);
    }
})